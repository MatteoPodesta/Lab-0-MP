// Matteo Podesta YOUR_LAST_NAME
// Lab #0

#include <iostream>
using namespace std;

int main()
{
    int num1, num2, product;

    cout << "\nMy name is  "
        "Matteo Podesta" << endl;

    cout << "\nEnter the first number >";
    cin >> num2;

    cout << "\nEnter the second number  ";
    cin >> num1;

    product = num1 + num2;
    cout << "\nThe sum of " << num1 << " and " << product << " is " << num2 << endl;

    return 0;
}

/*
  
My name is  Matteo Podesta

Enter the first number >12

Enter the second number  4

The sum of 4 and 16 is 12

C:\Users\Matteo\source\repos\3. Submit your First Project as a GitHub link - Lab #0\x64\Debug\ConsoleApplication1.exe (process 23340) exited with code 0.
Press any key to close this window . . .
*/